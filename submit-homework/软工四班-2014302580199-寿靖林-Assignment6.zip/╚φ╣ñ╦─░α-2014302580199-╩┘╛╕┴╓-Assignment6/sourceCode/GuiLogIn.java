import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class GuiLogIn {
	private JLabel labelUser;	//�û���
	private JLabel labelPassword;	//����
	
	private JTextField jtUser;
	private JPasswordField jtPassword;
	
	private JButton btFinish;	//���
	private JButton btBack;	//����
	
	private JFrame jf = new JFrame();;
	
	GuiLogIn()
	{
		jf.setLayout(null);
		jf.setTitle("��¼");
		
		labelUser = new JLabel();
		SetJLabel.setLabel(labelUser, "�û�����", 30, 10, 100, 30);
		jf.add(labelUser);
		
		labelPassword = new JLabel();
		SetJLabel.setLabel(labelPassword, "���룺", 30, 50, 100, 30);
		jf.add(labelPassword);
		
		jtUser = new JTextField();
		SetJTextField.setTextField(jtUser, "", 80, 10, 200, 30);
		jf.add(jtUser);
		
		jtPassword = new JPasswordField();
		SetJTextField.setTextField(jtPassword, "", 80, 50, 200, 30);
		jf.add(jtPassword);
		
		btFinish = new JButton();
		SetButton.setButton(btFinish ,"���", 50, 100, 70, 30);
		jf.add(btFinish);
		
		btBack = new JButton();
		SetButton.setButton(btBack ,"����", 160, 100, 70, 30);
		jf.add(btBack);
		
		SetJFrame.setJFrameSmall(jf);
		
		myEvent();
	}
	
	private boolean check(String name,String password){
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://127.0.0.1:3306/my_schema";
		String usernameSQL = "root";
		String passwordSQL = "123456";
		Connection con = null;
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//��������mysql���ݿ������
		//��������
		try {
			con = DriverManager.getConnection(url,usernameSQL,passwordSQL);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String search = "select * from 2014302580199_user where name=" + name ;
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(search);
			while(rs.next()){
				if(rs.getString(2).equals(password)){
					stmt.close();
					con.close();
					return true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	private void myEvent(){
		
		btFinish.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String name = jtUser.getText();
				String password = jtPassword.getText();
				if(name.isEmpty()){
					JOptionPane.showMessageDialog(null, "�û�������Ϊ�գ�");
					return;
				}else if(check(name,password)){
					GuiGoods guiGoods = new GuiGoods(0,name);
					jf.dispose();
				}
				else{
					JOptionPane.showMessageDialog(null, "�û������������");
					return;
				}
				
			}
		});
		
		btBack.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				GuiMain guiMain = new GuiMain();
				jf.dispose();
			}
		});
	}

}
