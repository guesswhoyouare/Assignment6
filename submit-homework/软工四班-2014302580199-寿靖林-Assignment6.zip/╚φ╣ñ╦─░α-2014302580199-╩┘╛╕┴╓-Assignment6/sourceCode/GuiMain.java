import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;



public class GuiMain{
	
	private JButton button1;
	private JButton button2;
	
	private JFrame jf = new JFrame();
	GuiMain()
	{
		jf.setLayout(null);
		jf.setTitle("���˵�");
		
		button1 = new JButton();
		SetButton.setButton(button1 ,"ע��", 30, 50, 100, 75);
		jf.add(button1);
		
		button2 = new JButton();
		SetButton.setButton(button2 ,"��¼", 140, 50, 100, 75);
		jf.add(button2);
		
		SetJFrame.setJFrameSmall(jf);

		myEvent();
	}	
	
	private void myEvent(){
		
		button1.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				GuiRegistered guiRegistered = new GuiRegistered();
				jf.dispose();
				
			}
			
		});
		
		button2.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				GuiLogIn guiLogIn = new GuiLogIn();
				jf.dispose();
			}
			
		});
	}
		
}