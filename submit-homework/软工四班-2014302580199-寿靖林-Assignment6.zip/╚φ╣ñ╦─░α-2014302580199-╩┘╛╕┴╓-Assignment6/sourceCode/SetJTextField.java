import javax.swing.JTextField;


public class SetJTextField {
	public static void setTextField(JTextField jt,String text,int x,int y,int width,int height){
		jt.setText(text);
		jt.setBounds(x, y, width, height);
	}
}
