import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class GuiRegistered {
	private JLabel labelUser; //�û���
	private JLabel labelPassword;	//����
	private JLabel labelPasswordCorrect;	//ȷ������
	private JLabel labelIid;	//����֤ID
	private JLabel labelAccount;	//�˺�money
	private JLabel labelName;	//����
	private JLabel labelPhone;	//�绰
	private JLabel labelAddress;//��ַ
	private JLabel labelCostPassword;	//֧������
	private JLabel labelEmail;	//����
	
	private JTextField jtUser;
	private JPasswordField jtPassword;
	private JPasswordField jtPasswordCorrect;
	private JTextField jtIid;
	private JTextField jtAccount;
	private JTextField jtName;
	private JTextField jtPhone;
	private JTextField jtAddress;
	private JTextField jtCostPassword;
	private JTextField jtEmail;
	
	private JButton btNext;
	private JButton btBack;
	
	private JFrame jf = new JFrame();
	
	GuiRegistered()
	{
		jf.setLayout(null);
		jf.setTitle("ע��");
		
		labelUser = new JLabel();
		SetJLabel.setLabel(labelUser, "�û���:", 40, 10, 100, 30);
		jf.add(labelUser);
		jtUser = new JTextField();
		SetJTextField.setTextField(jtUser, "", 140, 10, 200, 30);
		
		jf.add(jtUser);
		
		
		labelPassword = new JLabel();
		SetJLabel.setLabel(labelPassword, "����:", 40, 50, 100, 30);
		jf.add(labelPassword);
		jtPassword = new JPasswordField();
		SetJTextField.setTextField(jtPassword, "", 140, 50, 200, 30);
		jf.add(jtPassword);
		
		labelPasswordCorrect = new JLabel();
		SetJLabel.setLabel(labelPasswordCorrect, "ȷ������:", 40, 90, 100, 30);
		jf.add(labelPasswordCorrect);
		jtPasswordCorrect = new JPasswordField();
		SetJTextField.setTextField(jtPasswordCorrect, "", 140, 90, 200, 30);
		jf.add(jtPasswordCorrect);
		
		labelIid = new JLabel();
		SetJLabel.setLabel(labelIid, "����֤ID��", 40, 130, 100, 30);
		jf.add(labelIid);
		jtIid = new JTextField();
		SetJTextField.setTextField(jtIid, "", 140, 130, 200, 30);
		jf.add(jtIid);
		
		labelAccount = new JLabel();
		SetJLabel.setLabel(labelAccount, "�˺�money��", 40, 170, 100, 30);
		jf.add(labelAccount);
		jtAccount = new JTextField();
		SetJTextField.setTextField(jtAccount, "", 140, 170, 200, 30);
		jf.add(jtAccount);
		
		labelName = new JLabel();
		SetJLabel.setLabel(labelName, "������", 40, 210, 100, 30);
		jf.add(labelName);
		jtName = new JTextField();
		SetJTextField.setTextField(jtName, "", 140, 210, 200, 30);
		jf.add(jtName);
		
		labelPhone = new JLabel();
		SetJLabel.setLabel(labelPhone, "�绰��", 40, 250, 100, 30);
		jf.add(labelPhone);
		jtPhone = new JTextField();
		SetJTextField.setTextField(jtPhone, "", 140, 250, 200, 30);
		jf.add(jtPhone);
		
		
		labelAddress = new JLabel();
		SetJLabel.setLabel(labelAddress, "��ַ��", 40, 290, 100, 30);
		jf.add(labelAddress);
		jtAddress = new JTextField();
		SetJTextField.setTextField(jtAddress, "", 140, 290, 200, 30);
		jf.add(jtAddress);
		
		labelCostPassword = new JLabel();
		SetJLabel.setLabel(labelCostPassword, "֧�����룺", 40, 330, 100, 30);
		jf.add(labelCostPassword);
		jtCostPassword = new JTextField();
		SetJTextField.setTextField(jtCostPassword, "", 140, 330, 200, 30);
		jf.add(jtCostPassword);
		
		labelEmail = new JLabel();
		SetJLabel.setLabel(labelEmail, "���䣺", 40, 370, 100, 30);
		jf.add(labelEmail);
		jtEmail = new JTextField();
		SetJTextField.setTextField(jtEmail, "", 140, 370, 200, 30);
		jf.add(jtEmail);
		
		btNext = new JButton();
		SetButton.setButton(btNext, "���", 350, 450, 100, 30);
		jf.add(btNext);
		
		btBack = new JButton();
		SetButton.setButton(btBack, "����", 460, 450, 100, 30);
		jf.add(btBack);
		
		SetJFrame.setJFrameLarge(jf);
		
		myEvent();
	}
	
	//���û���Ϣ���ӵ����ݿ�
	private void insert(String name,String password,String iid,String money,String trueName,
			String phone,String address,String costPassword,String email){
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://127.0.0.1:3306/my_schema";
		String usernameSQL = "root";
		String passwordSQL = "123456";
		Connection con = null;
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//��������mysql���ݿ������
		//��������
		try {
			con = DriverManager.getConnection(url,usernameSQL,passwordSQL);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String insertSQL = "insert 2014302580199_user values(?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = con.prepareStatement(insertSQL);
			pstmt.setString(1, name);
			pstmt.setString(2, password);
			pstmt.setString(3, iid);
			pstmt.setString(4, money);
			pstmt.setString(5, trueName);
			pstmt.setString(6, phone);
			pstmt.setString(7, address);
			pstmt.setString(8, costPassword);
			pstmt.setString(9, email);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void myEvent(){
		
		btNext.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String name = jtUser.getText();
				String password = jtPassword.getText();
				String passwordCorrect = jtPasswordCorrect.getText();
				String iid = jtIid.getText();
				String money = jtAccount.getText();
				String trueName = jtName.getText();
				String phone = jtPhone.getText();
				String address = jtAddress.getText();
				String costPassword = jtCostPassword.getText();
				String email = jtEmail.getText();
				if(name.isEmpty() || password.isEmpty() || iid.isEmpty() || money.isEmpty()
						|| trueName.isEmpty() || phone.isEmpty() || address.isEmpty() 
						|| costPassword.isEmpty() || email.isEmpty()){
					JOptionPane.showMessageDialog(null, "ѡ���Ϊ�գ�");
					return;
				}
				if(!password.equals(passwordCorrect)){
					JOptionPane.showMessageDialog(null, "������ȷ����������ͬ��");
					return;
				}
				if(isName(name)){
					JOptionPane.showMessageDialog(null, "�û����Ѵ���!");
					return;
				}
				insert(name, password, iid, money, trueName, phone, address, costPassword, email);
				JOptionPane.showMessageDialog(null, "ע��ɹ���");
				GuiLogIn guiLogIn = new GuiLogIn();
				jf.dispose();
			}
		});
		
		btBack.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				GuiMain guiMain = new GuiMain();
				jf.dispose();
			}
		});
	}
	
	private boolean isName(String name){
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://127.0.0.1:3306/my_schema";
		String usernameSQL = "root";
		String passwordSQL = "123456";
		Connection con = null;
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//��������mysql���ݿ������
		//��������
		try {
			con = DriverManager.getConnection(url,usernameSQL,passwordSQL);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String search = "select * from 2014302580199_user";
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(search);
			while(rs.next()){
				if(rs.getString(1).equals(name)){
					stmt.close();
					con.close();
					return true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
}
