import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;


public class GuiGoods {
	
	private int petNumber = 12;
	
	private GuiUserInformation userInformation;
	private String userName;
	
	private JFrame jf;
	
	private JLabel jlTips;
	
	private JLabel [] jlName = new JLabel[2];
	private JLabel [] jlEat = new JLabel[2];
	private JLabel [] jlDrink = new JLabel[2];
	private JLabel [] jlLive = new JLabel[2];
	private JLabel [] jlHobby = new JLabel[2];
	
	private String [] petInformation = new String[petNumber];
	private String [] petName = new String[petNumber];
	private String [] petEat = new String[petNumber];
	private String [] petDrink = new String[petNumber];
	private String [] petLive = new String[petNumber];
	private String [] petHobby = new String[petNumber];
	
	private JTextArea [] jtGoods = new JTextArea[petNumber];	//������Ϣ
	
	private JButton jbNext;	//��һҳ
	private JButton jbBack;	//��һҳ
	private JButton jbCart;	//���ﳵ
	private JButton jbBackDialog;	//������һ������
	private JButton jbUser;	//�û���Ϣ
	
	private JButton [] jbAddCart = new JButton[petNumber]; //���ӵ����ﳵ
	
	private int page;
	
	GuiGoods(int key,String name){
		userName = name;
		page = key;
		
		for(int i = 0;i<petNumber;i++){
			jbAddCart[i] = new JButton();
		}
		
		GetPetData get = new GetPetData();
		petInformation = get.getPetInformation();
		petName = get.getName();
		petEat = get.getEat();
		petDrink = get.getDrink();
		petLive = get.getLive();
		petHobby = get.getHobby();
		
		jf = new JFrame();
		jf.setLayout(null);
		jf.setTitle("�����嵥");
		
		jlTips = new JLabel();
		SetJLabel.setLabel(jlTips, "���г���ļ۸��Ϊ1", 10, 0, 200, 20);
		jf.add(jlTips);
		
		for(int i = 0,y = 15;i<2;i++){
			jlName[i] = new JLabel();
			SetJLabel.setLabel(jlName[i], "name", 30, y, 100, 30);
			jf.add(jlName[i]);
			
			jlEat[i] = new JLabel();
			SetJLabel.setLabel(jlEat[i], "eat", 30, y+35, 100, 30);
			jf.add(jlEat[i]);
			
			jlDrink[i] = new JLabel();
			SetJLabel.setLabel(jlDrink[i], "drink", 30, y+70, 100, 30);
			jf.add(jlDrink[i]);
			
			jlLive[i] = new JLabel();
			SetJLabel.setLabel(jlLive[i], "live", 30, y+108, 100, 30);
			jf.add(jlLive[i]);
			
			jlHobby[i] = new JLabel();
			SetJLabel.setLabel(jlHobby[i], "hobby", 30, y+145, 100, 30);
			jf.add(jlHobby[i]);
			
			y += 250;
			if(key == 1){
				break;
			}
 		}
		
		jbNext = new JButton();
		SetButton.setButton(jbNext, "��һҳ", 475, 380, 100, 30);
		jf.add(jbNext);
		
		jbBack = new JButton();
		SetButton.setButton(jbBack, "��һҳ", 475, 420, 100, 30);
		jf.add(jbBack);
		
		jbCart = new JButton();
		SetButton.setButton(jbCart, "���ﳵ", 475, 70, 100, 30);
		jf.add(jbCart);
		
		jbBackDialog = new JButton();
		SetButton.setButton(jbBackDialog, "����", 475, 460, 100, 30);
		jf.add(jbBackDialog);
		
		jbUser = new JButton();
		SetButton.setButton(jbUser, "�û���Ϣ", 475, 30, 100, 30);
		jf.add(jbUser);
		
		int loopNumber = 0; 	//���ݵڼ���ͼƬ��������ʾ��Щ
		if(1 == key){
			loopNumber = 8;			
		}
		for(int x = 80,y = 20;loopNumber<petNumber;loopNumber++){
			jtGoods[loopNumber] = new JTextArea();
			jtGoods[loopNumber].setEditable(false);
			jtGoods[loopNumber].setText(petInformation[loopNumber]);
			jtGoods[loopNumber].setBounds(x, y, 75, 180);
			jf.add(jtGoods[loopNumber]);
			SetButton.setButton(jbAddCart[loopNumber], "+", x, y+190, 75, 20);
			jbAddCart[loopNumber].setToolTipText("���ӵ����ﳵ");
			jf.add(jbAddCart[loopNumber]);
			x += 90;
			if(3 == loopNumber){
				x = 80;
				y += 250;
			}
			if(7 == loopNumber){
				break;
			}
		}

		SetJFrame.setJFrameLarge(jf);
		
		myEvent();
	}
	
	private void myEvent(){
		jbNext.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				if(1 == page){
					JOptionPane.showMessageDialog(null, "�ѷ������һҳ");
					return;
				}
				GuiGoods guiGoods_2 = new GuiGoods(1,userName);
				jf.dispose();
			}
		});
		
		jbBack.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				if(0 == page){
					JOptionPane.showMessageDialog(null, "�ѷ�����һҳ");
				}
				GuiGoods guiGoods_1 = new GuiGoods(0,userName);
				jf.dispose();
			}
		});
		
		jbCart.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				GuiCart guiCart = new GuiCart(userName);
				jf.dispose();
			}
		});
		
		jbBackDialog.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				GuiLogIn guiLogin = new GuiLogIn();
				jf.dispose();
			}
		});
		
		jbUser.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				userInformation = new GuiUserInformation(userName);
				jf.dispose();
			}
		});
		
		jbAddCart[0].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				insert(petName[0],petEat[0],petDrink[0],petLive[0],petHobby[0]);
				JOptionPane.showMessageDialog(null, "���ӳɹ���");
			}
		});
		
		jbAddCart[1].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				insert(petName[1],petEat[1],petDrink[1],petLive[1],petHobby[1]);
				JOptionPane.showMessageDialog(null, "���ӳɹ���");
			}
		});
		
		jbAddCart[2].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				insert(petName[2],petEat[2],petDrink[2],petLive[2],petHobby[2]);
				JOptionPane.showMessageDialog(null, "���ӳɹ���");
			}
		});
		
		jbAddCart[3].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				insert(petName[3],petEat[3],petDrink[3],petLive[3],petHobby[3]);
				JOptionPane.showMessageDialog(null, "���ӳɹ���");
			}
		});
		
		jbAddCart[4].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				insert(petName[4],petEat[4],petDrink[4],petLive[4],petHobby[4]);
				JOptionPane.showMessageDialog(null, "���ӳɹ���");
			}
		});
		
		jbAddCart[5].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				insert(petName[5],petEat[5],petDrink[5],petLive[5],petHobby[5]);
				JOptionPane.showMessageDialog(null, "���ӳɹ���");
			}
		});
		
		jbAddCart[6].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				insert(petName[6],petEat[6],petDrink[6],petLive[6],petHobby[6]);
				JOptionPane.showMessageDialog(null, "���ӳɹ���");
			}
		});
		
		jbAddCart[7].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				insert(petName[7],petEat[7],petDrink[7],petLive[7],petHobby[7]);
				JOptionPane.showMessageDialog(null, "���ӳɹ���");
			}
		});
		
		jbAddCart[8].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				insert(petName[8],petEat[8],petDrink[8],petLive[8],petHobby[8]);
				JOptionPane.showMessageDialog(null, "���ӳɹ���");
			}
		});
		
		jbAddCart[9].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				insert(petName[9],petEat[9],petDrink[9],petLive[9],petHobby[9]);
				JOptionPane.showMessageDialog(null, "���ӳɹ���");
			}
		});
		
		jbAddCart[10].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				insert(petName[10],petEat[10],petDrink[10],petLive[10],petHobby[10]);
				JOptionPane.showMessageDialog(null, "���ӳɹ���");
			}
		});
		
		jbAddCart[11].addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				insert(petName[11],petEat[11],petDrink[11],petLive[11],petHobby[11]);
				JOptionPane.showMessageDialog(null, "���ӳɹ���");
			}
		});
	}
	
	private void insert(String name,String eat,String drink,String live,String hobby){
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://127.0.0.1:3306/my_schema";
		String usernameSQL = "root";
		String passwordSQL = "123456";
		Connection con = null;
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//��������mysql���ݿ������
		//��������
		try {
			con = DriverManager.getConnection(url,usernameSQL,passwordSQL);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String insertSQL = "insert into 2014302580199_cart(name,eat,drink,live,hobby,user) values(?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt = con.prepareStatement(insertSQL);
			pstmt.setString(1, name);
			pstmt.setString(2, eat);
			pstmt.setString(3, drink);
			pstmt.setString(4, live);
			pstmt.setString(5, hobby);
			pstmt.setString(6, userName);
			pstmt.executeUpdate();
			pstmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
