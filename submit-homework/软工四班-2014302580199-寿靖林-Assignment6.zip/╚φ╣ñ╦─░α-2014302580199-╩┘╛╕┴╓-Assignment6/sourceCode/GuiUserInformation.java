import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class GuiUserInformation {
	
	private User user;
	private JLabel labelUser; //�û���
	private JLabel labelPassword;	//����
	private JLabel labelIid;	//����֤ID
	private JLabel labelAccount;	//�˺�money
	private JLabel labelName;	//����
	private JLabel labelPhone;	//�绰
	private JLabel labelAddress;//��ַ
	private JLabel labelCostPassword;	//֧������
	private JLabel labelEmail;	//����
	
	private JLabel jtUser;
	private JLabel jtPassword;
	private JLabel jtIid;
	private JLabel jtAccount;
	private JLabel jtName;
	private JLabel jtPhone;
	private JLabel jtAddress;
	private JLabel jtCostPassword;
	private JLabel jtEmail;

	private JButton btBack;
	
	private JFrame jf = new JFrame();
	
	GuiUserInformation(String name)
	{
		user = new User(name);
		
		jf.setLayout(null);
		jf.setTitle("ע��");
		
		labelUser = new JLabel();
		SetJLabel.setLabel(labelUser, "�û���:", 40, 10, 100, 30);
		jf.add(labelUser);
		jtUser = new JLabel();
		SetJLabel.setLabel(jtUser, user.getName(), 140, 10, 200, 30);
		jf.add(jtUser);
		
		
		labelPassword = new JLabel();
		SetJLabel.setLabel(labelPassword, "����:", 40, 50, 100, 30);
		jf.add(labelPassword);
		jtPassword = new JLabel();
		SetJLabel.setLabel(jtPassword, user.getPassword(), 140, 50, 200, 30);
		jf.add(jtPassword);

		labelIid = new JLabel();
		SetJLabel.setLabel(labelIid, "����֤ID��", 40, 90, 100, 30);
		jf.add(labelIid);
		jtIid = new JLabel();
		SetJLabel.setLabel(jtIid, user.getIid(), 140, 90, 200, 30);
		jf.add(jtIid);
		
		labelAccount = new JLabel();
		SetJLabel.setLabel(labelAccount, "�˺�money��", 40, 130, 100, 30);
		jf.add(labelAccount);
		jtAccount = new JLabel();
		SetJLabel.setLabel(jtAccount, user.getMoney(), 140, 130, 200, 30);
		jf.add(jtAccount);
		
		labelName = new JLabel();
		SetJLabel.setLabel(labelName, "������", 40, 170, 100, 30);
		jf.add(labelName);
		jtName = new JLabel();
		SetJLabel.setLabel(jtName, user.getTrueName(), 140, 170, 200, 30);
		jf.add(jtName);
		
		labelPhone = new JLabel();
		SetJLabel.setLabel(labelPhone, "�绰��", 40, 210, 100, 30);
		jf.add(labelPhone);
		jtPhone = new JLabel();
		SetJLabel.setLabel(jtPhone, user.getPhone(), 140, 210, 200, 30);
		jf.add(jtPhone);
		
		labelAddress = new JLabel();
		SetJLabel.setLabel(labelAddress, "��ַ��", 40, 250, 100, 30);
		jf.add(labelAddress);
		jtAddress = new JLabel();
		SetJLabel.setLabel(jtAddress, user.getAddress(), 140, 250, 200, 30);
		jf.add(jtAddress);
		
		labelCostPassword = new JLabel();
		SetJLabel.setLabel(labelCostPassword, "֧�����룺", 40, 290, 100, 30);
		jf.add(labelCostPassword);
		jtCostPassword = new JLabel();
		SetJLabel.setLabel(jtCostPassword, user.getCostPassword(), 140, 290, 200, 30);
		jf.add(jtCostPassword);
		
		labelEmail = new JLabel();
		SetJLabel.setLabel(labelEmail, "���䣺", 40, 330, 100, 30);
		jf.add(labelEmail);
		jtEmail = new JLabel();
		SetJLabel.setLabel(jtEmail, user.getEmail(), 140, 330, 200, 30);
		jf.add(jtEmail);
	
		btBack = new JButton();
		SetButton.setButton(btBack, "����", 460, 450, 100, 30);
		jf.add(btBack);
		
		SetJFrame.setJFrameLarge(jf);
		
		myEvent();
	}
	
	private void myEvent(){
		btBack.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				GuiGoods guiGoods_0 = new GuiGoods(0,user.getName());
				jf.dispose();
			}
		});
	}

}
