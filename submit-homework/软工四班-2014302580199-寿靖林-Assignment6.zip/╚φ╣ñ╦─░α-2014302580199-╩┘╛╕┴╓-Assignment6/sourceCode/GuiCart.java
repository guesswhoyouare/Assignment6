import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;
import javax.swing.border.EmptyBorder;


public class GuiCart {
	
	private JFrame jf;
	private JPanel jp;
	
	private JLabel jlPetName;	//��������
	private JLabel jlPetNumber;        //��������                                                      
	
	private JButton jbCost;		//֧��
	private JButton jbBack;	//����
	private JButton jbClean;	//���
	
	private JTextArea jtPetName;
	//private JTextArea jtPetNumber;
	
	private String userName;	//��¼�û�
	private int cost = 0;	//������
	private int [] number = new int[12]; //��¼������
	private String petName[] = {"dog","cat","turtle","parrot","hamster","squirrel","rabbit","snake",
			"lizard","fish","myna","canary"};
	
	private User user;
	
	public GuiCart(String name){
		userName = name;
		
		jf = new JFrame();
		jf.setLayout(null);
		jf.setTitle("���ﳵ");
		
		jlPetName = new JLabel();
		SetJLabel.setLabel(jlPetName, "��������", 100, 10, 200, 30);
		jlPetName.setFont(new java.awt.Font("Dialog",0,30));
		jf.add(jlPetName);
		
		jlPetNumber = new JLabel();
		SetJLabel.setLabel(jlPetNumber, "��������", 300, 10, 200, 30);
		jlPetNumber.setFont(new java.awt.Font("Dialog",0,30));
		jf.add(jlPetNumber);
		
		jbCost = new JButton();
		SetButton.setButton(jbCost, "֧��", 365, 460, 100, 30);
		jf.add(jbCost);
		jbBack = new JButton();
		SetButton.setButton(jbBack, "����", 475, 460, 100, 30);
		jf.add(jbBack);
		jbClean = new JButton();
		SetButton.setButton(jbClean, "���", 475, 30, 100, 30);
		jf.add(jbClean);
		
		jtPetName = new JTextArea();
		jtPetName.setEditable(false);
		jtPetName.setFont(new java.awt.Font("Dialog",0,20));
		jtPetName.setText(getCartData());
		JScrollPane sc = new JScrollPane(jtPetName);
		sc.setBounds(90, 80, 350, 350);
		sc.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		jf.add(sc);
		SetJFrame.setJFrameLarge(jf);
		
		myEvent();
	}
	
	private String getCartData(){
		String resultCart = null;
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://127.0.0.1:3306/my_schema";
		String username = "root";
		String password = "123456";
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//��������mysql���ݿ������
		//��������
		
		Connection con;
		try {
			con = DriverManager.getConnection(url,username,password);
			
			String select = "select * from 2014302580199_cart where user="+userName;
			Statement stmt;
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(select);
			while(rs.next()){
				switch(rs.getString(2).toString()){
				case "dog":
					number[0]++;
					break;
				case "cat":
					number[1]++;
					break;
				case "turtle":
					number[2]++;
					break;
				case "parrot":
					number[3]++;
					break;
				case "hamster":
					number[4]++;
					break;
				case "squirrel":
					number[5]++;
					break;
				case "rabbit":
					number[6]++;
					break;
				case "snake":
					number[7]++;
					break;
				case "lizard":
					number[8]++;
					break;
				case "fish":
					number[9]++;
					break;
				case "myna":
					number[10]++;
					break;
				case "canary":
					number[11]++;
					break;
				}
			}
			for(int i = 0;i<12;i++){
				if(number[i] != 0){
					resultCart += petName[i]+"\t\t"+"X"+number[i]+"\n\n";
					cost += number[i];
				}
			}
			resultCart += "\n�ܼۣ�  " + String.valueOf(cost);
			stmt.close();
			con.close();
			return resultCart;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	private void myEvent(){
		
		jbBack.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				GuiGoods guiGoods_0 = new GuiGoods(0,userName);
				jf.dispose();
			}
		});
		
		jbClean.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				clean();
				JOptionPane.showMessageDialog(null, "��չ��ﳵ�ɹ���");
			}
		});
		
		jbCost.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				user = new User(userName);
				int sure = JOptionPane.showConfirmDialog(null, "ȷ��֧����");
				if(sure == 0){
					if(Integer.valueOf(user.getMoney()) < cost){
						JOptionPane.showMessageDialog(null, "�����˻�û���㹻���ʽ�!");
						return;
					}
					else{
						JOptionPane.showMessageDialog(null, "֧���ɹ�");
						updateMoney(Integer.valueOf(user.getMoney()) - cost);
						clean();
						GuiGoods guiGoods_0 = new GuiGoods(0,userName);
						jf.dispose();
					}
				}
				
			}
		});
	}
	
	private void updateMoney(int number){
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://127.0.0.1:3306/my_schema";
		String username = "root";
		String password = "123456";
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//��������mysql���ݿ������
		//��������
		
		Connection con;
		try {
			con = DriverManager.getConnection(url,username,password);
			
			String update = "update 2014302580199_user set money=? where name=" + userName;
			PreparedStatement pstmt = con.prepareStatement(update);
			pstmt.setString(1, String.valueOf(number));
			pstmt.executeUpdate();
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	private void clean(){
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://127.0.0.1:3306/my_schema";
		String username = "root";
		String password = "123456";
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//��������mysql���ݿ������
		//��������
		
		Connection con;
		try {
			con = DriverManager.getConnection(url,username,password);
			
			String delete = "delete from 2014302580199_cart where user=" + userName;
			Statement stmt;
			stmt = con.createStatement();
			stmt.executeUpdate(delete);
			stmt.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		jtPetName.setText("");
	}
}
