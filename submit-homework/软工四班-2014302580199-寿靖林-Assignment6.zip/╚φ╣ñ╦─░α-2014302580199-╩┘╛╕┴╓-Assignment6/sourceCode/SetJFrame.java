import javax.swing.JFrame;


public class SetJFrame {
	
	public static void setJFrameLarge(JFrame jf){
		
		jf.setDefaultCloseOperation(jf.EXIT_ON_CLOSE);
		jf.setResizable(false);
		jf.setSize(600, 530);
		jf.setLocationRelativeTo(null);
		jf.setVisible(true);
	}	
	
	public static void setJFrameSmall(JFrame jf)
	{
		jf.setDefaultCloseOperation(jf.EXIT_ON_CLOSE);
		jf.setResizable(false);
		jf.setSize(300, 200);
		jf.setLocationRelativeTo(null);
		jf.setVisible(true);
	}
}
