import javax.swing.JLabel;


public class SetJLabel {
	public static void setLabel(JLabel jl,String text,int x,int y,int width,int height){
		
		jl.setText(text);
		jl.setBounds(x, y, width, height);
	}
}
