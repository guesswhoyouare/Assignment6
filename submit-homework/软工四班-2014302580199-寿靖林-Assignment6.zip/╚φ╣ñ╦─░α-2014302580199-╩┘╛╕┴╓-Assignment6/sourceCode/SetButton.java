import javax.swing.JButton;


public class SetButton {
	public static void setButton(JButton jb,String text,int x,int y,int width,int height){
		
		jb.setText(text);
		jb.setBounds(x, y, width, height);
		
	}
}
