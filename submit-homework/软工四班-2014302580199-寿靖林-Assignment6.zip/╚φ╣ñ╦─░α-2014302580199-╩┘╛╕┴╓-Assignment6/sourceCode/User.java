import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class User {
	private String name; 
	private String password;
	private String iid; 
	private String money;
	private String trueName; 
	private String phone;
	private String address;
	private String costPassword;
	private String email; 
	User(String name){
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://127.0.0.1:3306/my_schema";
		String usernameSQL = "root";
		String passwordSQL = "123456";
		Connection con = null;
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//��������mysql���ݿ������
		//��������
		try {
			con = DriverManager.getConnection(url,usernameSQL,passwordSQL);
			String search = "select * from 2014302580199_user where name=" +name;
			
			Statement stmt;
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(search);
			while(rs.next()){
				this.name = rs.getString(1);
				this.password = rs.getString(2);
				this.iid = rs.getString(3);
				this.money = rs.getString(4);
				this.trueName = rs.getString(5);
				this.phone = rs.getString(6);
				this.address = rs.getString(7);
				this.costPassword = rs.getString(8);
				this.email = rs.getString(9);
				break;
			}
			stmt.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	public String getName(){
		return this.name;
	}
	
	public String getPassword(){
		return this.password;
	}
	
	public String getIid(){
		return this.iid;
	}
	
	public String getMoney(){
		return this.money;
	}
	
	public String getTrueName(){
		return this.trueName;
	}
	
	public String getPhone(){
		return this.phone;
	}
	
	public String getAddress(){
		return this.address;
	}
	
	public String getCostPassword(){
		return this.costPassword;
	}
	
	public String getEmail(){
		return this.email;
	}
}
