import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class GetPetData {
	
	private int petNumber = 12;
	
	private String [] name = new String[petNumber];	//����
	private String [] eat = new String[petNumber];	//�Ե�
	private String [] drink = new String[petNumber];	//�ȵ�
	private String [] live = new String[petNumber];	//��������
	private String [] hobby = new String[petNumber];	//����
	private String [] petInformation = new String[petNumber];
	
	GetPetData(){
		
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://127.0.0.1:3306/new_schema";
		String username = "root";
		String password = "test";
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//��������mysql���ݿ������
		//��������
		
		Connection con;
		try {
			con = DriverManager.getConnection(url,username,password);
			
			String search = "select * from pet";
			
			Statement stmt;
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(search);
			int i = 0;
			while(rs.next()){
				
				name[i] = rs.getString(2);
				eat[i] = rs.getString(3);
				drink[i] = rs.getString(4);
				live[i] = rs.getString(5);
				hobby[i] = rs.getString(6);
				petInformation[i] = 
						name[i]+"\n\n"+eat[i]+"\n\n"+drink[i]+"\n\n"+live[i]+"\n\n"+hobby[i];
				i++;
			}
			stmt.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//��ȡ��������
	public String[] getName(){
		return name;
	}
	//��ȡ����ʳ��
	public String[] getEat(){
		return eat;
	}
	//��ȡ���ﰮ�ȵ�
	public String[] getDrink(){
		return drink;
	}
	//��ȡ����ס��
	public String[] getLive(){
		return live;
	}
	//��ȡ���ﰮ��
	public String[] getHobby(){
		return hobby;
	}
	//��ȡ����������Ϣ
	public String[] getPetInformation(){
		return petInformation;
	}
	
}
